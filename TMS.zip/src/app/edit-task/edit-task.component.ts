import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ManagerService } from '../service/manager.service';
import { DataService } from '../service/data.service';
import { Task } from '../pojo/task';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent {

  taskInfoForm: FormGroup = new FormGroup({});

  errorMessage: string | undefined;



  constructor(private fb: FormBuilder, private router: Router, private managerService: ManagerService, private dataservice: DataService) { }

  taskEmpty!: Task;


  ngOnInit(): void {
    this.taskInfoForm = this.fb.group({
      taskId: [null, Validators.required],
      title: [null, Validators.required],
      description: [null, Validators.required],
      status: [null, Validators.required],
      startDate: [null, Validators.required],
      endDate:[null, Validators.required]
    });

    this.dataservice.currentTask.subscribe(task => this.taskEmpty = task)
    console.log(this.taskEmpty)

    this.taskInfoForm.patchValue({
      taskId: this.taskEmpty.taskId,
      title: this.taskEmpty.title,
      description: this.taskEmpty.description,
      status: this.taskEmpty.status,
      startDate: this.taskEmpty.startDate,
      endDate: this.taskEmpty.endDate
    });
  }

  onSubmit() {

    const taskData: Task = {
      taskId: this.taskEmpty.taskId,
      title: this.taskInfoForm.value.title,
      description: this.taskInfoForm.value.description,
      status: this.taskInfoForm.value.status,
      startDate: this.taskInfoForm.value.startDate,
      endDate: this.taskInfoForm.value.endDate
    };

    this.managerService.updateTask(this.taskEmpty.taskId, taskData).subscribe(
      (data) => {
        console.warn(data);
        alert('Task updated successfully');
        this.router.navigate(['manager-control'])
      })
      ,
      (error: any) => {
        console.error('Error:', error);
      }

   }
}