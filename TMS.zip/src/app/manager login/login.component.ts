// src/app/login/login.component.ts

import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ManagerService } from '../service/manager.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-manager-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm !: FormGroup;
  showPassword !: boolean;
  isManager: boolean = true;




  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  constructor(private fb: FormBuilder,
    private router:Router, private managerService:ManagerService,
    private cookieService: CookieService) {}

  ngOnInit(): void {
    this.initLoginForm();
  }

  initLoginForm(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onLogin(): void {
    if (this.loginForm.valid) {
      console.log('Login successful!');
      this.managerService.managerLogin(this.loginForm.value.email, this.loginForm.value.password)
        .subscribe(
          (data) => {
            console.log(data);
            this.router.navigate(['/manager-control']);
            this.cookieService.set('userId', data);
          },
          (error) => {
            console.error('Login failed', error);
            alert('Login failed. Please check your email and password.');
          }
        );
    }
  }
  
  isManagerForm(): boolean {
    return this.isManager;
  }
}