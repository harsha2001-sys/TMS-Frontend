import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-component',
  templateUrl: './manager.html',
  styleUrls: ['./manager.css']
})
export class ManagerComponentComponent {
   
    
}
