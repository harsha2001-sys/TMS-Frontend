import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-component',
  templateUrl: './employee.html',
  styleUrls: ['./employee.css']
})
export class EmployeeComponentComponent {

}
