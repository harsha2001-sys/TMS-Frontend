import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable, catchError, throwError } from 'rxjs';
import { Manager } from '../pojo/manager';
import { Task } from '../pojo/task';
import { Employee } from '../pojo/employee';
import { TStatus } from '../pojo/enum';
@Injectable({
  providedIn: 'root'
})
export class ManagerService {
  
  private baseUrl = 'http://localhost:9237';
  
  constructor(private httpClient: HttpClient) { }

  getEmployeesByManagerId(managerId: number): Observable<any> {
    return this.httpClient.get('http://localhost:9237/getEmployeesByManagerId/' + `${managerId}`)
  }

  getTasksByManagerId(managerId: number): Observable<any> {
    return this.httpClient.get('http://localhost:9237/getAssignedTaskByManagerId/' + `${managerId}`)
  }

  managerLogin(email: String, password: String): Observable<any> {
    return this.httpClient.get('http://localhost:9237/managerLogin/' + `${email}/` + `${password}`)
  }


  signUp(user: Manager): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      
    };

    return this.httpClient.post(`${this.baseUrl}/createManager/`, user,  { responseType: 'text' as 'json' })
      .pipe(
        catchError(this.handleError)
      );
  }

  createTask(user: Task, managerId: number): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',

      }),
    };

    return this.httpClient.post(`${this.baseUrl}/createTask/` + `${managerId}`, user, { responseType: 'text' as 'json' })
      .pipe(
        catchError(this.handleError)
      );
  }

  createEmployee(user: Employee, managerId: number): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',

      }),
    };

    return this.httpClient.post(`${this.baseUrl}/createEmployee/` + `${managerId}`, user, { responseType: 'text' as 'json' })
      .pipe(
        catchError(this.handleError)
      );
  }

  getEmployeeByEmployeeId(employeeId: number){
  
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.httpClient.get<Employee>(`${this.baseUrl}/getEmployeeByEmployeeId/`+`${employeeId}`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
  }

  getManagerByManagerId( managerId: number){
  
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.httpClient.get<Manager>(`${this.baseUrl}/getManagerbyManagerId/`+`${managerId}`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
 
  }

  updateEmployee(employeeId: number ,employee : Employee ){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    
    return this.httpClient.post<Employee>(`${this.baseUrl}/editEmployee/`+`${employeeId}`, employee , { responseType: 'text' as 'json' })
    .pipe(
      catchError(this.handleError)
    );
  }

  getTaskByTaskId( taskId: number){
  
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.httpClient.get<Task>(`${this.baseUrl}/getTaskByTaskId/`+`${taskId}`, httpOptions)
    .pipe(
      catchError(this.handleError)
    );
 
  }

  updateTask(taskId: number ,task : Task ){
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    
    return this.httpClient.post<Task>(`${this.baseUrl}/editTask/`+`${taskId}`, task , { responseType: 'text' as 'json' })
    .pipe(
      catchError(this.handleError)
    );
  }
  
  assignTask(employeeName: String ,title : String): Observable<any> {
    return this.httpClient.post<any>('http://localhost:9237/assignTaskforEmployee/' + `${employeeName}/` +`${title}` ,{})
  }
  
  updateTasks(employeeName: String ,title : String): Observable<any> {
    // http://localhost:9237/updateEmployeeForTask/109/12123
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.httpClient.post<any>('http://localhost:9237/updateEmployeeForTask/' + `${employeeName}/` +`${title}`,httpOptions )
  }

  deleteEmployeeById(employee: number): Observable<any> {
    return this.httpClient.delete<string>('http://localhost:9237/deleteEmployeeById/' + `${employee}` )
  }

  deleteTaskById(task: number): Observable<any> {
    return this.httpClient.delete<string>('http://localhost:9237/deleteTaskById/' + `${task}`)
  }

  employeeLogin(email: String, password: String): Observable<any> {
    return this.httpClient.get('http://localhost:9237/employeeLogin/' + `${email}/` + `${password}`, {responseType: 'text' as 'json' })
  }

  getTasksByEmployeeId(managerId: number): Observable<any> {
    return this.httpClient.get('http://localhost:9237/getTaskByEmployeeId/' + `${managerId}`)
  }

  getAllEmployeesName(): Observable<any> {
    return this.httpClient.get('http://localhost:9237/getAllEmployeesName/')
  }

  getAllTasksName(): Observable<any> {
    return this.httpClient.get('http://localhost:9237/getAllTasksName/')
  }

  updateTaskById(task: number,status:TStatus): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };
    return this.httpClient.put<any>('http://localhost:9237/updateTaskStatusbyId/' + `${task}/` +`${status}` ,httpOptions );
  }

  private handleError(error: any): Observable<any> {
    console.error('An error occurred:', error);
    return throwError(error.error);
  }

  
}

