import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Employee } from '../pojo/employee';
import { Task } from '../pojo/task';

 
@Injectable({
  providedIn: 'root'
})
export class DataService {
  getEmployeeByEmployeeId(employeeId: number) {
    throw new Error('Method not implemented.');
  }
 
  constructor() { }
 
  private employee = new BehaviorSubject<Employee>(new Employee);
  currentEmployee = this.employee.asObservable();
 
  updateEmployee(employee : Employee){
    this.employee.next(employee);
  }

  private task = new BehaviorSubject<Task>(new Task);
  currentTask = this.task.asObservable();
 
  updateTask(task : Task){
    this.task.next(task);
  }
}
