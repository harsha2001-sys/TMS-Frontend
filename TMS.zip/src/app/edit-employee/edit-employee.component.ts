import { Component } from '@angular/core';
import { Validators } from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../service/data.service';
import { Employee } from '../pojo/employee';
import { ManagerService } from '../service/manager.service';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent {

  employeeInfoForm: FormGroup = new FormGroup({});


  errorMessage: string | undefined;



  constructor(private fb: FormBuilder, private router: Router, private managerService: ManagerService, private dataservice: DataService) { }

  employeeEmpty!: Employee;


  ngOnInit(): void {
    this.employeeInfoForm = this.fb.group({
      employeeId: [null, Validators.required],
      employeeName: [null, Validators.required],
      emailId: [null, Validators.required],
      userName: [null, Validators.required],
    });
    this.dataservice.currentEmployee.subscribe(employee => this.employeeEmpty = employee)
    console.log(this.employeeEmpty)

    this.employeeInfoForm.patchValue({
      employeeId: this.employeeEmpty.employeeId,
      employeeName: this.employeeEmpty.employeeName,
      emailId: this.employeeEmpty.emailId,
      userName: this.employeeEmpty.userName
    });

  }

  onSubmit() {

    const employeeData: Employee = {
      employeeId: this.employeeEmpty.employeeId,
      employeeName: this.employeeInfoForm.value.employeeName,
      emailId: this.employeeInfoForm.value.emailId,
      userName: this.employeeInfoForm.value.userName,
      password: this.employeeInfoForm.value.password
    };

    this.managerService.updateEmployee(this.employeeEmpty.employeeId, employeeData).subscribe(
      (data) => {
        console.warn(data);
        alert('Employee updated successfully');
        this.router.navigate(['manager-control'])
      })
      ,
      (error: any) => {
        console.error('Error:', error);
      }
  }
}

