export class Manager{
  
	 managerId!: number;

	 firstName!: String;

	 lastName!: String;

	 emailId!: String;

	 userName!: String;

	 password!: String;


}