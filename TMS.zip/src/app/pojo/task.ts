import  {TStatus} from "../pojo/enum"
import { Employee } from "./employee";

export class Task{
      taskId !: number;

	  title!: String;

	  description!: String;
	 
	   status ! : TStatus ;

	   startDate !: Date;

	   endDate! : Date;
	//    employeeDTO!:Employee

// 	private Manager managerTask;
	
// 	private Employee taskEmployee;

}
