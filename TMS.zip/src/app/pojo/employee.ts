export class Employee{
  
      employeeId!:number;
    
	
	  employeeName!:String;
    
	
	  emailId!:String ;
	

	  userName!:String;
	
	
	  password!:String;
	
// 	private Manager managerEmployee;
	
// 	private List<Task> tasks;
	
}