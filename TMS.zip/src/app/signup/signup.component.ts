

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Manager } from '../pojo/manager';
import { ManagerService } from '../service/manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user: Manager = {
    managerId: 0,
    firstName: '',
    lastName: '',
    emailId: '',
    userName: '',
    password: ''
  }
  signupForm: FormGroup;
  showPassword: boolean = false;

  constructor(private fb: FormBuilder, private managerService: ManagerService, private router: Router) {
    // Initialize the form and its controls
     this.signupForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      // managerId: ['', [Validators.required]]
    });
  }

  // Method to toggle password visibility
  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  onSignup(): void {
    // this.user.managerId = this.signupForm.value.managerId
    this.user.lastName = this.signupForm.value.lastName
    this.user.emailId = this.signupForm.value.email
    this.user.firstName = this.signupForm.value.firstName
    this.user.password = this.signupForm.value.password
    console.log(this.user);

    this.managerService.signUp(this.user).subscribe(
      response => {
        alert(response)
        this.router.navigate(["/manager/login"])
         
      },
      error => {
        console.error('User creation failed:', error);
        alert(error)
      }
    );
  }
}
