import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { ManagerService } from '../service/manager.service';
import { Employee } from '../pojo/employee';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent {

    employee: Employee = {
    employeeId: 0,
    employeeName: '',
    emailId: '',
    userName:  '',
    password:''
  }

  createForm: FormGroup;
  showPassword: boolean = false;
  errorMessage!: String;

  constructor(private fb: FormBuilder,
    private router:Router,private managerService:ManagerService,private cookieService: CookieService) {
      this.createForm = this.fb.group({
      // employeeId: ['', Validators.required],
      employeeName: ['', Validators.required],
      userName: ['', Validators.required],
      emailId: ['', [Validators.required, Validators.email]],
     
    });
  }

  create() {
    // this.employee.employeeId = this.createForm.value.employeeId
    this.employee.employeeName = this.createForm.value.employeeName
    this.employee.emailId = this.createForm.value.emailId
    this.employee.userName = this.createForm.value.userName

    


    let userId: number = parseInt(this.cookieService.get('userId'));
    if(!isNaN(userId)){
      console.log("Hello Harsh::"+userId)
    this.managerService.createEmployee(this.employee,userId).subscribe(
      response => {
        console.log('User created:', response);
        alert("Employee created successfully")
        this.router.navigate(['manager-control'])

      },
      error=>{
        alert(error)
        // this.errorMessage = error;
      }
    );
  }
}

}