import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './manager login/login.component';
import { ManagerComponentComponent } from './manager/manager';
import { EmployeeloginComponent } from './employeelogin/employeelogin.component';
import { ManagerControlsComponent } from './manager-controls/manager-controls.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { CreateTaskComponent } from './create-task/create-task.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { EmployeeControlsComponent } from './employee-controls/employee-controls.component';
import { AssignTaskComponent } from './assign-task/assign-task.component';
import { UpdateTaskComponent } from './update-task/update-task.component';

const routes: Routes = [
  { path: '', component: WelcomePageComponent },
  { path: 'welcome', component: WelcomePageComponent },
  {
    path: 'manager/signup',
    component: SignupComponent,

  },
  { path: '', component: SignupComponent },
  { path: 'manager/login', component: LoginComponent },
  { path: '', redirectTo: 'signup', pathMatch: 'full' },
  { path: 'employee/login', component: EmployeeloginComponent },
  { path: 'manager-control', component: ManagerControlsComponent },
  { path: 'create-employee', component: CreateEmployeeComponent, },
  { path: 'create-task', component: CreateTaskComponent },
  { path: 'assign-task', component: AssignTaskComponent },
  { path: 'update-task', component: UpdateTaskComponent },
  { path: 'edit-employee', component:EditEmployeeComponent },
  { path: 'edit-task', component:EditTaskComponent },
  { path: 'employee-control', component: EmployeeControlsComponent },
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
