import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManagerService } from '../service/manager.service';
import { DataService } from '../service/data.service';
import { CookieService } from 'ngx-cookie-service';
import { TStatus } from '../pojo/enum';

@Component({
  selector: 'app-employee-controls',
  templateUrl: './employee-controls.component.html',
  styleUrls: ['./employee-controls.component.css']
})
export class EmployeeControlsComponent implements OnInit {
  showStatusUpdatePopup !: boolean;
  completedStatus = TStatus.COMPLETED;
  activeStatus = TStatus.ACTIVE;
  cancelledStatus = TStatus.CANCELLED;

  constructor(
    private router: Router,
    private managerService: ManagerService,
    private cookieService: CookieService
  ) { }

  showHomeButtons: boolean = true;
  showTaskTable: boolean = false;
  showSignOutConfirmation: boolean = false;
  searchTerm: string = '';
  itemsPerPage: number = 5;
  currentPage: number = 1;
  tasksData: any[] = [];
  userId: number = parseInt(this.cookieService.get('userId'));
  username!: string

  ngOnInit() {
    const userIdString = this.cookieService.get('userId');
    this.userId = parseInt(userIdString);
    this.getUsername(this.userId)
    if (isNaN(this.userId)) {
      console.error('Invalid userId:', userIdString);
     
      return;
    }

    this.managerService.getTasksByEmployeeId(this.userId).subscribe(
      data => {
        this.tasksData = data;
      },
      error => {
        console.error('Error fetching tasks:', error);
      }
    );
  }

  showSignOutPopup(): void {
    this.showSignOutConfirmation = true;
  }

  cancelSignOut(): void {
    this.showSignOutConfirmation = false;
  }

  signOut(): void {
    console.log('Signing out...');
    this.router.navigate(['../employee/login']);

    // this.updateTaskStatus(1,TStatus.CANCELLED);
  }
  taskId!: number
  showPopUp(taskId: number) {
    this.showStatusUpdatePopup = true;
    this.taskId = taskId;

  }
  updateTaskStatus(status: TStatus): void {
    console.log('updateTaskStatus called with taskId:', this.taskId, 'and status:', status);

    this.managerService.updateTaskById(this.taskId, status)
      .subscribe(
        (response) => {
          console.log('Update successfully');
          location.reload()
        },
        (error) => {
          console.error('Update failed', error);

        }
      );

    this.showStatusUpdatePopup = false;

  }
  cancelStatusUpdate(): void {

    this.showStatusUpdatePopup = false;
  }

  getUsername(employeeId: number): void {
    this.managerService.getEmployeeByEmployeeId(this.userId).subscribe(
      (response) => {
        console.log('username got successfully');
        this.cookieService.set("username",response.userName)
        this.username=this.cookieService.get("username")
        console.log(this.username)
      },
      (error) => {
        console.error('error');

      }
    )
  }
}

