
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ManagerService } from '../service/manager.service';
import { Manager } from '../pojo/manager';
import { DataService } from '../service/data.service';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { Task } from '../pojo/task';

@Component({
  selector: 'app-manager-controls',
  templateUrl: './manager-controls.component.html',
  styleUrls: ['./manager-controls.component.css']
})
export class ManagerControlsComponent {
  employeeIdToDel!: number;
  tasks: any;

  constructor(private router: Router,
    private managerService: ManagerService, private dataService: DataService, private cookieService: CookieService,private cdr: ChangeDetectorRef) {

  }

  
  ngOnInit() {
    const userIdString = this.cookieService.get('userId');
    this.userId = parseInt(userIdString);
    this.getUsername(this.userId)
    if (isNaN(this.userId)) {
      console.error('Invalid userId:', userIdString);
     
      return;
    }

  
  }

  signOut() {
    console.log('Signing out...');
    this.router.navigate(['../manager/login']);
  }

  showHomeButtons: boolean = true;
  showEmployeeTable: boolean = false;
  showTaskTable: boolean = false;
  showSignOutConfirmation: boolean = false;
  showDeleteConfirmation: boolean = false;
  showDeleteConfirmationEmployee: boolean = false;
  searchTerm: string = '';
  taskToDelete: any;
  employeesData: any[] = [];
  tasksData: any[] = [];
  employeeToDelete: any;
  username!: string
  userId: number = parseInt(this.cookieService.get('userId'));
  


  hideHomeButtons(): void {
    this.showHomeButtons = true;
    this.showEmployeeTable = false;
    this.showTaskTable = false;
  }

  toggleEmployeeTable(): void {
    this.showHomeButtons = false;
    this.showEmployeeTable = true;
    this.showTaskTable = false;
    this.managerService.getEmployeesByManagerId(this.userId).subscribe(data => {
      this.employeesData = data;
    })
  }

  toggleTaskTable(): void {
    this.showHomeButtons = false;
    this.showEmployeeTable = false;
    this.showTaskTable = true;
    this.managerService.getTasksByManagerId(this.userId).subscribe(data => {
      this.tasksData = data;
    })
  }
  // search bar employee
  get filteredEmployees(): any[] {
    return this.employeesData.filter(employee =>
      employee.employeeName.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  // search bar task
  get filteredTasks(): any[] {
    return this.tasksData.filter(task =>
      task.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  showSignOutPopup(): void {
    this.showSignOutConfirmation = true;
  }

  cancelSignOut(): void {
    this.showSignOutConfirmation = false;
  }

  showDeletePopup(employee: any): void {

    this.employeeToDelete = employee;
    this.showDeleteConfirmation = true;

  }

  cancelDelete(): void {

    this.employeeToDelete = null;
    this.showDeleteConfirmation = false;
    this.showDeleteConfirmationEmployee = false;

  }


  getEmployee(employeeId: number) {

    this.managerService.getEmployeeByEmployeeId(employeeId).subscribe((data) => {
      this.dataService.updateEmployee(data)
      console.log(this.dataService.updateEmployee)
      console.log(employeeId)
      this.router.navigate(['/edit-employee']);

    })
  }

  getTask(taskId: number) {

    this.managerService.getTaskByTaskId(taskId).subscribe((data) => {
      this.dataService.updateTask(data)
      console.log(this.dataService.updateTask)
      console.log(taskId)
      this.router.navigate(['/edit-task']);

    })
  }

  deleteItem() {
    console.log('Deleting employee ID:', this.employeeIdToDel);
    this.managerService.deleteEmployeeById(this.employeeIdToDel).subscribe(
      (response) => {
        console.log(response);
        location.reload()
      },
      (error) => {
        console.error('Error deleting employee:', error.error);
      }
    );
  }

  

  showDeleteConfirmationFn(employeeId: number) {
    this.employeeIdToDel = employeeId;
    this.showDeleteConfirmationEmployee = true;
    console.log(employeeId)
  }

  deleteTaskItem() {
    console.log('Deleting task ID:', this.taskToDelete);
    this.managerService.deleteTaskById(this.taskToDelete).subscribe(
      (response) => {
        console.log(response);
         location.reload()
      },
      (error) => {
        console.error('Error deleting task:', error.error);
        alert(error)
      }
    );
  }

  showDeleteConfirmationTask(taskId: number) {
    this.taskToDelete = taskId;
    this.showDeleteConfirmation = true;
    console.log(taskId)
  }

getUsername(managerId: number): void {
    this.managerService.getManagerByManagerId(this.userId).subscribe(
      (response) => {
        console.log('username got successfully');
        this.cookieService.set("username",response.userName)
        this.username=this.cookieService.get("username")
        console.log(this.username)
      },
      (error) => {
        console.error('error');
      }
    )
  }

}




