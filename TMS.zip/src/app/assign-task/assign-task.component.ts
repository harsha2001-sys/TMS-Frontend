import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ManagerService } from '../service/manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-assign-task',
  templateUrl: './assign-task.component.html',
  styleUrls: ['./assign-task.component.css']
})
export class AssignTaskComponent implements OnInit{
  assignTaskForm: FormGroup;
  errorMessage!: String;
  employeeNames!: string[];
  selectedEmployee!: string;
  task!: string[]
  selectedTask!: string;

  constructor(private fb: FormBuilder, private managerService: ManagerService, private router: Router) {
    this.assignTaskForm = this.fb.group({
      employeeName: ['', Validators.required],
      title: ['', Validators.required],
    });
  }

  assignTask() {
   
    let employeeName = this.assignTaskForm.value.employeeName
    let title = this.assignTaskForm.value.title
    console.log(this.assignTaskForm);
    
    this.managerService.assignTask(employeeName, title)
      .subscribe(
        (response) => {
          if (response) {
            alert("Task assigned sucessfully")
            this.router.navigate(["/manager-control"])
          }
          else {
            alert("error")
          }
        },
        (error) => {
          console.error('Assign Task failed', error);
            alert(error.error)
        }
      );
  }

  getAllEmployee() {
    this.managerService.getAllEmployeesName()
    .subscribe (
      (data: any) => {
  
        this.employeeNames = data;
        console.log(this.employeeNames)
      },
      (error: any) => {
        console.error('Error fetching employee names:', error);
      }
    );
  }
  

  getAllTask() {
    this.managerService.getAllTasksName()
    .subscribe (
      (data: any) => {
  
        this.task = data;
        console.log(this.employeeNames)
      },
      (error: any) => {
        console.error('Error fetching employee names:', error);
      }
    );
  }


  ngOnInit() {
  
    this.getAllEmployee();
    this.getAllTask();
   
  }
}
