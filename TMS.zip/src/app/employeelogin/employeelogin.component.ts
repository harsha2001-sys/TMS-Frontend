import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ManagerService } from '../service/manager.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-employeelogin',
  templateUrl: './employeelogin.component.html',
  styleUrls: ['./employeelogin.component.css']
})
export class EmployeeloginComponent {
  loginForm!: FormGroup;
  showPassword!: boolean;

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  constructor(private fb: FormBuilder,
    private router: Router, private managerService: ManagerService,
    private cookieService: CookieService) { }


  ngOnInit(): void {
    this.initLoginForm();
  }

  initLoginForm(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onLogin(): void {
    if (this.loginForm.valid) {
      console.log('Login successful!');
      this.managerService.employeeLogin(this.loginForm.value.email, this.loginForm.value.password)
        .subscribe(
          (data) => {
            console.log(data);
            this.router.navigate(['/employee-control']);
            this.cookieService.set('userId', data);
          },
          (error) => {
            console.error('Login failed', error);
            alert('Login failed. Please check your email and password.');
          }
        );
    }
  }

}

