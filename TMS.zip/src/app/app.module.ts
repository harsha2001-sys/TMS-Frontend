// src/app/app.module.ts

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomePageComponent } from './welcome-page/welcome-page.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './manager login/login.component';
import { ManagerComponentComponent } from './manager/manager';
import { EmployeeloginComponent } from './employeelogin/employeelogin.component';
import { ManagerControlsComponent } from './manager-controls/manager-controls.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { CreateTaskComponent } from './create-task/create-task.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { EmployeeControlsComponent } from './employee-controls/employee-controls.component';
import { AssignTaskComponent } from './assign-task/assign-task.component';
import { UpdateTaskComponent } from './update-task/update-task.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomePageComponent,
    ManagerComponentComponent,
    SignupComponent,
    LoginComponent,
    EmployeeloginComponent,
    ManagerControlsComponent,
    CreateEmployeeComponent,
    CreateTaskComponent,
    EditEmployeeComponent,
    EditTaskComponent,
    EmployeeControlsComponent,
    AssignTaskComponent,
    UpdateTaskComponent
  
  ],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule, AppRoutingModule ,HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
  
})
export class AppModule {}
