import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ManagerService } from '../service/manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css']
})
export class UpdateTaskComponent {
  updateTaskForm: FormGroup;
  employeeNames!: string[];
  selectedEmployee!: string;
  task!: string[]
  selectedTask!: string;


  constructor(private fb: FormBuilder, private managerService: ManagerService, private router: Router) {
    this.updateTaskForm = this.fb.group({
      employeeName: ['', Validators.required],
      title: ['', Validators.required],
    });
  }

  updateTask() {
    let employeeName = this.updateTaskForm.value.employeeName
    let title = this.updateTaskForm.value.title
    console.log(this.updateTaskForm);
    
    this.managerService.updateTasks(employeeName, title)
      .subscribe(
        (response) => {
          if (response) {
            alert("Task updated sucessfully")
            this.router.navigate(["/manager-control"])
          }
          else {
            alert("error")
          }
        },
        (error) => {
          console.error('Assign update failed', error);
          // this.errorMessage = error;
            alert(error.error)
        }
      );
  }

  getAllEmployee() {
    this.managerService.getAllEmployeesName()
    .subscribe (
      (data: any) => {
  
        this.employeeNames = data;
        console.log(this.employeeNames)
      },
      (error: any) => {
        console.error('Error fetching employee names:', error);
      }
    );
  }
  

  getAllTask() {
    this.managerService.getAllTasksName()
    .subscribe (
      (data: any) => {
  
        this.task = data;
        console.log(this.employeeNames)
      },
      (error: any) => {
        console.error('Error fetching employee names:', error);
      }
    );
  }

  ngOnInit() {
  
    this.getAllEmployee();
    this.getAllTask();
   
  }

}
