import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Task } from '../pojo/task';
import { CookieService } from 'ngx-cookie-service';
import { TStatus } from '../pojo/enum';
import { ManagerService } from '../service/manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-task',
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.css']
})
export class CreateTaskComponent {
  task: Task = {
    taskId: 0,
    title: '',
    description: '',
    status:TStatus.ACTIVE ,
    startDate:  new Date(),
    endDate:  new Date()
  }

  createTaskForm: FormGroup;

  constructor(private fb: FormBuilder,private cookieService: CookieService,private managerService:ManagerService,
    private router:Router) {
    this.createTaskForm = this.fb.group({
      // taskId: ['', Validators.required],
      title: ['', Validators.required],
      description: ['', Validators.required],
      status: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
    });
  }

  ngOnInit(): void {}

  submit(): void {
  
      // this.task.taskId = this.createTaskForm.value.taskId
      this.task.title = this.createTaskForm.value.title
      this.task.description = this.createTaskForm.value.description
      this.task.status = this.createTaskForm.value.status
      this.task.startDate = this.createTaskForm.value.startDate
      this.task.endDate = this.createTaskForm.value.endDate
      console.log(this.task);
  

      let userId: number = parseInt(this.cookieService.get('userId'), 10);
      if(!isNaN(userId)){
        console.log("Hello Harsh::"+userId)
      this.managerService.createTask(this.task,userId).subscribe(
        response => {
          console.log('User created:', response);
          alert("Task created successfully")
          this.router.navigate(['manager-control'])
        },
        error => {
          alert(error)
        }
      );
    }
  }
 }

